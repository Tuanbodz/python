package com.backend.cookshare.recipe_management.controller;

import com.backend.cookshare.common.dto.PageResponse;
import com.backend.cookshare.interaction.dto.response.SearchHistoryResponse;
import com.backend.cookshare.recipe_management.dto.ApiResponse;
import com.backend.cookshare.recipe_management.dto.response.IngredientResponse;
import com.backend.cookshare.recipe_management.dto.response.SearchReponse;

import com.backend.cookshare.recipe_management.service.SearchService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/searchs")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class SearchController {
    SearchService searchService;
    @GetMapping("/recipe")
    public ApiResponse<PageResponse<SearchReponse>> searchRecipes(
            @RequestParam String title,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "title") String sortBy,
            @RequestParam(defaultValue = "ASC") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("DESC")
                ? Sort.Direction.DESC
                : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        PageResponse<SearchReponse> results = searchService.searchRecipesByName(title, pageable);
        return ApiResponse.<PageResponse<SearchReponse>>builder()
                .result(results)
                .build();
    }
    @GetMapping("/recipebyingredient")
    public ApiResponse<PageResponse<SearchReponse>> searchIngredients(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) List<String> ingredients,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "title") String sortBy,
            @RequestParam(defaultValue = "ASC") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("DESC")
                ? Sort.Direction.DESC
                : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        PageResponse<SearchReponse> results = searchService.searchRecipesByIngredient(title, ingredients, pageable);
        return ApiResponse.<PageResponse<SearchReponse>>builder()
                .result(results)
                .build();
    }
    @GetMapping("/ingredients")
    public ApiResponse<List<IngredientResponse>> top10MostIngredients() {
        return ApiResponse.<List<IngredientResponse>>builder()
                .result(searchService.top10MostUsedIngredients())
                .build();
    }
    @GetMapping("/history")
    public ApiResponse<List<SearchHistoryResponse>> getSearchHistory() {
        return ApiResponse.<List<SearchHistoryResponse>>builder()
                .result(searchService.getSearchHistory())
                .build();
    }
    @GetMapping("/user")
    public ApiResponse<PageResponse<SearchReponse>> searchRecipesByName(
            @RequestParam String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "title") String sortBy,
            @RequestParam(defaultValue = "ASC") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("DESC")
                ? Sort.Direction.DESC
                : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        PageResponse<SearchReponse> results = searchService.searchRecipesByfullName(name, pageable);
        return ApiResponse.<PageResponse<SearchReponse>>builder()
                .result(results)
                .build();
    }
    @GetMapping("/user/suggestions")
    public ResponseEntity<ApiResponse<List<String>>> getUserSuggestions(
            @RequestParam(required = false) String query,
            @RequestParam(defaultValue = "5") int limit) {

        if (query == null || query.trim().length() < 2) {
            return ResponseEntity.ok(
                    ApiResponse.<List<String>>builder()
                            .code(1000)
                            .message("Query too short")
                            .result(Collections.emptyList())
                            .build()
            );
        }

        List<String> suggestions = searchService.getUsernameSuggestions(query.trim(), limit);

        return ResponseEntity.ok(
                ApiResponse.<List<String>>builder()
                        .code(1000)
                        .message("Success")
                        .result(suggestions)
                        .build()
        );
    }

    @GetMapping("/recipe/suggestions")
    public ResponseEntity<ApiResponse<List<String>>> getRecipeSuggestions(
            @RequestParam(required = false) String query,
            @RequestParam(defaultValue = "5") int limit) {

        if (query == null || query.trim().length() < 2) {
            return ResponseEntity.ok(
                    ApiResponse.<List<String>>builder()
                            .code(1000)
                            .message("Query too short")
                            .result(Collections.emptyList())
                            .build()
            );
        }

        List<String> suggestions = searchService.getRecipeSuggestions(query.trim(), limit);

        return ResponseEntity.ok(
                ApiResponse.<List<String>>builder()
                        .code(1000)
                        .message("Success")
                        .result(suggestions)
                        .build()
        );
    }
}
